# FIXED

threads.obj: ../threads.c
threads.obj: ../threads.h
threads.obj: ../G8RTOS/G8RTOS_Semaphores.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
threads.obj: ../MultimodDrivers/multimod.h
threads.obj: ../MultimodDrivers/multimod_uart.h
threads.obj: ../MultimodDrivers/multimod_i2c.h
threads.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_gpio.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/i2c.h
threads.obj: ../MultimodDrivers/multimod_BMI160.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/tm4c123gh6pm.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_i2c.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/gpio.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/sysctl.h
threads.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h
threads.obj: ../MultimodDrivers/multimod_OPT3001.h
threads.obj: ../MultimodDrivers/multimod_LaunchpadButtons.h
threads.obj: ../MultimodDrivers/multimod_LaunchpadLED.h

../threads.c:

../threads.h:

../G8RTOS/G8RTOS_Semaphores.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

../MultimodDrivers/multimod.h:

../MultimodDrivers/multimod_uart.h:

../MultimodDrivers/multimod_i2c.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_gpio.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/i2c.h:

../MultimodDrivers/multimod_BMI160.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/tm4c123gh6pm.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_i2c.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/gpio.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h:

../MultimodDrivers/multimod_OPT3001.h:

../MultimodDrivers/multimod_LaunchpadButtons.h:

../MultimodDrivers/multimod_LaunchpadLED.h:

