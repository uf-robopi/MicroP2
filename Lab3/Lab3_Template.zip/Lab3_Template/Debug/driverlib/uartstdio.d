# FIXED

driverlib/uartstdio.obj: ../driverlib/uartstdio.c
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
driverlib/uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h
driverlib/uartstdio.obj: E:/ti/tiva_drivers/inc/hw_ints.h
driverlib/uartstdio.obj: E:/ti/tiva_drivers/inc/hw_memmap.h
driverlib/uartstdio.obj: E:/ti/tiva_drivers/inc/hw_types.h
driverlib/uartstdio.obj: E:/ti/tiva_drivers/inc/hw_uart.h
driverlib/uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/debug.h
driverlib/uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/interrupt.h
driverlib/uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/rom.h
driverlib/uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/rom_map.h
driverlib/uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/sysctl.h
driverlib/uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/uart.h
driverlib/uartstdio.obj: ../driverlib/uartstdio.h

../driverlib/uartstdio.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h:

E:/ti/tiva_drivers/inc/hw_ints.h:

E:/ti/tiva_drivers/inc/hw_memmap.h:

E:/ti/tiva_drivers/inc/hw_types.h:

E:/ti/tiva_drivers/inc/hw_uart.h:

C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/debug.h:

C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/interrupt.h:

C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/rom.h:

C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/rom_map.h:

C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab3_2024/driverlib/uart.h:

../driverlib/uartstdio.h:

