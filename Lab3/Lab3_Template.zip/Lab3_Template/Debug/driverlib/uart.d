# FIXED

driverlib/uart.obj: ../driverlib/uart.c
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
driverlib/uart.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_ints.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_sysctl.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_uart.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/debug.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/interrupt.h
driverlib/uart.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h

../driverlib/uart.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_ints.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_uart.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/debug.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/interrupt.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h:

