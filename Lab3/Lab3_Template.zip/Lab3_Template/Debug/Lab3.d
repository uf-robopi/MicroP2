# FIXED

Lab3.obj: ../Lab3.c
Lab3.obj: ../G8RTOS/G8RTOS.h
Lab3.obj: ../G8RTOS/G8RTOS_Scheduler.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
Lab3.obj: ../G8RTOS/G8RTOS_Structures.h
Lab3.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
Lab3.obj: ../G8RTOS/G8RTOS_Structures.h
Lab3.obj: ../G8RTOS/G8RTOS_Semaphores.h
Lab3.obj: ../MultimodDrivers/multimod.h
Lab3.obj: ../MultimodDrivers/multimod_uart.h
Lab3.obj: ../MultimodDrivers/multimod_i2c.h
Lab3.obj: E:/ti/tiva_drivers/inc/hw_memmap.h
Lab3.obj: E:/ti/tiva_drivers/inc/hw_gpio.h
Lab3.obj: E:/ti/tiva_drivers/driverlib/i2c.h
Lab3.obj: ../MultimodDrivers/multimod_BMI160.h
Lab3.obj: E:/ti/tiva_drivers/inc/tm4c123gh6pm.h
Lab3.obj: E:/ti/tiva_drivers/inc/hw_types.h
Lab3.obj: E:/ti/tiva_drivers/inc/hw_i2c.h
Lab3.obj: E:/ti/tiva_drivers/driverlib/gpio.h
Lab3.obj: E:/ti/tiva_drivers/driverlib/sysctl.h
Lab3.obj: E:/ti/tiva_drivers/driverlib/uart.h
Lab3.obj: ../MultimodDrivers/multimod_OPT3001.h
Lab3.obj: ../MultimodDrivers/multimod_LaunchpadButtons.h
Lab3.obj: ../MultimodDrivers/multimod_LaunchpadLED.h
Lab3.obj: ../G8RTOS/G8RTOS_CriticalSection.h
Lab3.obj: ../threads.h

../Lab3.c:

../G8RTOS/G8RTOS.h:

../G8RTOS/G8RTOS_Scheduler.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

../G8RTOS/G8RTOS_Structures.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

../G8RTOS/G8RTOS_Structures.h:

../G8RTOS/G8RTOS_Semaphores.h:

../MultimodDrivers/multimod.h:

../MultimodDrivers/multimod_uart.h:

../MultimodDrivers/multimod_i2c.h:

E:/ti/tiva_drivers/inc/hw_memmap.h:

E:/ti/tiva_drivers/inc/hw_gpio.h:

E:/ti/tiva_drivers/driverlib/i2c.h:

../MultimodDrivers/multimod_BMI160.h:

E:/ti/tiva_drivers/inc/tm4c123gh6pm.h:

E:/ti/tiva_drivers/inc/hw_types.h:

E:/ti/tiva_drivers/inc/hw_i2c.h:

E:/ti/tiva_drivers/driverlib/gpio.h:

E:/ti/tiva_drivers/driverlib/sysctl.h:

E:/ti/tiva_drivers/driverlib/uart.h:

../MultimodDrivers/multimod_OPT3001.h:

../MultimodDrivers/multimod_LaunchpadButtons.h:

../MultimodDrivers/multimod_LaunchpadLED.h:

../G8RTOS/G8RTOS_CriticalSection.h:

../threads.h:

