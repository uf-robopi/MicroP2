# FIXED

G8RTOS/src/G8RTOS_Scheduler.obj: ../G8RTOS/src/G8RTOS_Scheduler.c
G8RTOS/src/G8RTOS_Scheduler.obj: ../G8RTOS/G8RTOS_Scheduler.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../G8RTOS/G8RTOS_Structures.h
G8RTOS/src/G8RTOS_Scheduler.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../G8RTOS/G8RTOS_Structures.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../G8RTOS/G8RTOS_Semaphores.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod_uart.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod_i2c.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_gpio.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/i2c.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod_BMI160.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/tm4c123gh6pm.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_i2c.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/gpio.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/sysctl.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod_OPT3001.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod_LaunchpadButtons.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../MultimodDrivers/multimod_LaunchpadLED.h
G8RTOS/src/G8RTOS_Scheduler.obj: ../G8RTOS/G8RTOS_CriticalSection.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_ints.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_nvic.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/systick.h
G8RTOS/src/G8RTOS_Scheduler.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/interrupt.h

../G8RTOS/src/G8RTOS_Scheduler.c:

../G8RTOS/G8RTOS_Scheduler.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

../G8RTOS/G8RTOS_Structures.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

../G8RTOS/G8RTOS_Structures.h:

../G8RTOS/G8RTOS_Semaphores.h:

../MultimodDrivers/multimod.h:

../MultimodDrivers/multimod_uart.h:

../MultimodDrivers/multimod_i2c.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_gpio.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/i2c.h:

../MultimodDrivers/multimod_BMI160.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/tm4c123gh6pm.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_i2c.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/gpio.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h:

../MultimodDrivers/multimod_OPT3001.h:

../MultimodDrivers/multimod_LaunchpadButtons.h:

../MultimodDrivers/multimod_LaunchpadLED.h:

../G8RTOS/G8RTOS_CriticalSection.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_ints.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_nvic.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/systick.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/interrupt.h:

