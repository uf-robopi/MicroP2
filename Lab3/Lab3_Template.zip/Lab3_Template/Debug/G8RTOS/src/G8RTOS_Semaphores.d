# FIXED

G8RTOS/src/G8RTOS_Semaphores.obj: ../G8RTOS/src/G8RTOS_Semaphores.c
G8RTOS/src/G8RTOS_Semaphores.obj: ../G8RTOS/G8RTOS_Semaphores.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
G8RTOS/src/G8RTOS_Semaphores.obj: ../G8RTOS/G8RTOS_CriticalSection.h
G8RTOS/src/G8RTOS_Semaphores.obj: ../G8RTOS/G8RTOS_Structures.h
G8RTOS/src/G8RTOS_Semaphores.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
G8RTOS/src/G8RTOS_Semaphores.obj: ../G8RTOS/G8RTOS_Structures.h

../G8RTOS/src/G8RTOS_Semaphores.c:

../G8RTOS/G8RTOS_Semaphores.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

../G8RTOS/G8RTOS_CriticalSection.h:

../G8RTOS/G8RTOS_Structures.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

../G8RTOS/G8RTOS_Structures.h:

