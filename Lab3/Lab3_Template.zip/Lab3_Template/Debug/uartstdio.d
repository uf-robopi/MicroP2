# FIXED

uartstdio.obj: ../uartstdio.c
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
uartstdio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_ints.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_uart.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/debug.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/interrupt.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/rom.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/rom_map.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/sysctl.h
uartstdio.obj: C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h
uartstdio.obj: ../uartstdio.h

../uartstdio.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_ints.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/inc/hw_uart.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/debug.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/interrupt.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/rom.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/rom_map.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab3_2025_template/driverlib/uart.h:

../uartstdio.h:

