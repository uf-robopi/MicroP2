import cv2
import argparse
from time import sleep

from face_detect_img import face_detect, draw_face_boxes

if __name__=="__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--out_path", type=str, default="data/webcam_out.mp4")
    parser.add_argument("--casc_Path", type=str, default="haarcascade_frontalface_default.xml")
    args = parser.parse_args()

    out_video_name = args.out_path
    cascPath = args.casc_Path

    faceCascade = cv2.CascadeClassifier(cascPath)

    video_capture = cv2.VideoCapture(0)

    out_video = cv2.VideoWriter(out_video_name, cv2.VideoWriter_fourcc(*'mp4v'), 30, (320,240))

    while True:
        if not video_capture.isOpened():
            print('Unable to load camera.')
            sleep(5)
            pass

        ret, frame = video_capture.read()
        frame_resized =  cv2.resize(frame,(640,480))
        faces = face_detect(frame_resized, faceCascade)
        image_out = draw_face_boxes(frame_resized, faces)

        # Display the resulting frame
        cv2.imshow('Video', image_out)
        out_video.write(image_out)

        # Press q to exit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # When everything is done, release the capture
    out_video.release()
    video_capture.release()
    cv2.destroyAllWindows()
