# FIXED

GFX_Library.obj: ../GFX_Library.c
GFX_Library.obj: ../MultimodDrivers/multimod_ST7789.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
GFX_Library.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
GFX_Library.obj: ../GFX_Library.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_memmap.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_types.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/sysctl.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/gpio.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/pin_map.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/ssi.h
GFX_Library.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/rom.h

../GFX_Library.c:

../MultimodDrivers/multimod_ST7789.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

../GFX_Library.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_memmap.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_types.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/sysctl.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/gpio.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/pin_map.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/ssi.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/rom.h:

