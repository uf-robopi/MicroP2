# FIXED

main.obj: ../main.c
main.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/interrupt.h
main.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/sysctl.h
main.obj: C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/gpio.h

../main.c:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/interrupt.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/sysctl.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/gpio.h:

