// Lab 2 - Solutions, uP2 Fall 2025
// Created: 2023-07-31
// Updated: 2025-07-15
// STATUS: Functioning Well
#include "./MultimodDrivers/multimod.h"
#include <driverlib/timer.h> // utiliser les externs voici pour les includes pourraient pas �tre

// part
 //#define part_ab
#define part_ec

void Timer0A_Init(void) {
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0)) { }
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet() - 1);
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    IntMasterEnable();
    TimerEnable(TIMER0_BASE, TIMER_A);
    SysCtlDelay(10);
}

int main(void) {
  // Sets clock speed to 80 MHz. You'll need it!
  SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

  // init various multimod items
  multimod_init();

  // EC
  #ifdef part_ec
  Timer0A_Init();
  #endif

  // debug
  UARTprintf("inits complete!\n");

  // Part A, B
  #ifdef part_ab
  while(1) {
    int16_t accel_x = BMI160_AccelXGetResult();
    int16_t accel_y = BMI160_AccelYGetResult();
    int16_t accel_z = BMI160_AccelZGetResult();
    UARTprintf("x : %d     ", accel_x);
    UARTprintf("y : %d     ", accel_y);
    UARTprintf("z : %d     ", accel_z);

    uint32_t opt_result = OPT3001_GetResult();
    UARTprintf("opt : %d \n\n", opt_result);

    SysCtlDelay(5000000);
  }
  #endif

  while(1);
}

void Timer0A_Handler(void) {
  // make sure startup_ccs.c has interrupt vector pointing to this ISR (extern'd as well)

  #ifdef part_ec
  // Clear the timeout interrupt flag for Timer0A
  TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

  ST7789_Fill(ST7789_BLACK);

  int16_t accel_x = BMI160_AccelXGetResult();
  int16_t accel_y = BMI160_AccelYGetResult();
  int16_t accel_z = BMI160_AccelZGetResult();
  uint32_t opt_result = OPT3001_GetResult();

  char accel_x_string[64], accel_y_string[64], accel_z_string[64], opt_string[64];
  snprintf(accel_x_string, sizeof(accel_x_string), "x: %d", accel_x);
  snprintf(accel_y_string, sizeof(accel_y_string), "y: %d", accel_y);
  snprintf(accel_z_string, sizeof(accel_z_string), "z: %d", accel_z);
  snprintf(opt_string, sizeof(opt_string), "opt: %d", opt_result);
  ST7789_DrawStringStatic(accel_x_string, ST7789_WHITE, 50, 80);
  ST7789_DrawStringStatic(accel_y_string, ST7789_WHITE, 50, 90);
  ST7789_DrawStringStatic(accel_z_string, ST7789_WHITE, 50, 100);
  ST7789_DrawStringStatic(opt_string,     ST7789_WHITE, 50, 110);

  #endif
}

