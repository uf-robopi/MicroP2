// multimod_OPT3001.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for OPT3001 functions

/************************************Includes***************************************/

#include "../multimod_OPT3001.h"

#include <stdint.h>
#include "../multimod_i2c.h"

/************************************Includes***************************************/

/********************************Public Functions***********************************/

// OPT3001_Init
// Initializes OPT3001, configures it to continuous conversion mode.
// Return: void
void OPT3001_Init(void) {

    // Initialize I2C module
    I2C_Init(I2C_A_BASE);

    // Set the correct configuration byte for continuous conversions
    // OPT3001_WriteRegister(OPT3001_CONFIG_ADDR, OPT3001_CONFIG_RESET | OPT3001_CONFIG_M_BM);
    OPT3001_WriteRegister(OPT3001_CONFIG_ADDR, 0xC610);


    return;
}

// OPT3001_WriteRegister
// Writes to a register in the OPT3001.
// Param uint8_t "addr": Register address of the OPT3001.
// Param uint16_t "data": 16-bit data to write to the register.
// Return: void
void OPT3001_WriteRegister(uint8_t addr, uint16_t data) {
    // Read the datasheet!
    // Complete this function

    // convert data into an uint8 array
    uint8_t arr[3] = {addr, (uint8_t)(data >> 8), (uint8_t) data};

    // send register we want to write to
    I2C_WriteSingle(I2C_A_BASE, OPT3001_ADDR, addr);

    // write using I2C write multiple function
    I2C_WriteMultiple(I2C_A_BASE, OPT3001_ADDR, arr, 3);

    return;

}

// OPT3001_ReadRegister
// Reads from a register in the OPT3001.
// Param uint8_t "addr": Register address of the OPT3001.
// Return: uint16_t
uint16_t OPT3001_ReadRegister(uint8_t addr) {
    // Complete this function

    // initalize variables
    uint16_t data;                              // uint 16 data that we are returning
    uint8_t arr[2];                             // uint 8 data array that is returned from readMultiple

    // set register to read
    I2C_WriteSingle(I2C_A_BASE, OPT3001_ADDR, addr);

    // read data
    I2C_ReadMultiple(I2C_A_BASE, OPT3001_ADDR, arr, 2);

    // convert array to data var and return
    // the OPT3001 returns MSB first so the order is reversed 0 -> 1, not 1 -> 0
    data = (((uint16_t) arr[0]) << 8) | ((uint16_t) arr[1]);

    return data;
}

// OPT3001_GetResult
// Gets conversion result, calculates byte result based on datasheet
// and configuration settings.
// Return: uint32_t
uint32_t OPT3001_GetResult(void) {
    // Check if data is ready first
    // while(!(OPT3001_ReadRegister(OPT3001_CONFIG_ADDR) & OPT3001_CONFIG_CRF));

    uint16_t result = OPT3001_ReadRegister(OPT3001_RESULT_ADDR);

    result = LUX((result >> 12 & 0xF), (result & 0x0FFF));

    return result;
}

// OPT3001_SetLowLimit
// Sets the low limit register.
// Param uint16_t "exp": Exponential bound
// Param uint16_t "result": Conversion bound
// Return: void
void OPT3001_SetLowLimit(uint16_t exp, uint16_t result) {
    OPT3001_WriteRegister(OPT3001_LOWLIMIT_ADDR, (exp << OPT3001_RESULT_E_S | (result & 0xFFF)));

    return;
}

// OPT3001_SetHighLimit
// Sets the high limit register.
// Param uint16_t "exp": Exponential bound
// Param uint16_t "result": Conversion bound
// Return: void
void OPT3001_SetHighLimit(uint16_t exp, uint16_t result) {
    OPT3001_WriteRegister(OPT3001_HIGHLIMIT_ADDR, (exp << OPT3001_RESULT_E_S | (result & 0xFFF)));

    return;
}

// OPT3001_GetChipID
// Gets the chip ID of the OPT3001.
// Return: uint16_t
uint16_t OPT3001_GetChipID(void) {
    return OPT3001_ReadRegister(OPT3001_DEVICEID_ADDR);
}

/********************************Public Functions***********************************/
