# FIXED

driverlib/ssi.obj: ../driverlib/ssi.c
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
driverlib/ssi.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ints.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ssi.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_sysctl.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/interrupt.h
driverlib/ssi.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/ssi.h

../driverlib/ssi.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ints.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ssi.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/interrupt.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/ssi.h:

