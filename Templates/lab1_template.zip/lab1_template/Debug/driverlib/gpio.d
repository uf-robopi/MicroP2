# FIXED

driverlib/gpio.obj: ../driverlib/gpio.c
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
driverlib/gpio.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_gpio.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ints.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_sysctl.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/gpio.h
driverlib/gpio.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/interrupt.h

../driverlib/gpio.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_gpio.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ints.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/gpio.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/interrupt.h:

