# FIXED

driverlib/crc.obj: ../driverlib/crc.c
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
driverlib/crc.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
driverlib/crc.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ccm.h
driverlib/crc.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h
driverlib/crc.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h
driverlib/crc.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/crc.h
driverlib/crc.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h

../driverlib/crc.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ccm.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/crc.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h:

