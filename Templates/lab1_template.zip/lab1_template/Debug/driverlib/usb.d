# FIXED

driverlib/usb.obj: ../driverlib/usb.c
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
driverlib/usb.obj: E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ints.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_sysctl.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_usb.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/interrupt.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/sysctl.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/udma.h
driverlib/usb.obj: C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/usb.h

../driverlib/usb.c:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

E:/ti/ccs_install/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_ints.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_memmap.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_types.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/inc/hw_usb.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/debug.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/interrupt.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/sysctl.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/udma.h:

C:/Users/kingp/OneDrive/uP2/lab1_2025/driverlib/usb.h:

