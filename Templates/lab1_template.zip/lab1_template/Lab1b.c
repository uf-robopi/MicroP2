// Lab 0, uP2 Fall 2023
// Created: 2023-07-31
// Updated: 2023-07-31
// Lab 0 is intended to introduce you to the code composer studio IDE, how to flash programs,
// reading the tm4c123gh6pm datasheet, and how to initialize the UART console to read
// data from the microcontroller.

/************************************Includes***************************************/

#include <stdint.h>
#include <stdbool.h>

#include <inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_gpio.h>

#include <driverlib/uartstdio.h>
#include <driverlib/gpio.h>
#include <driverlib/uart.h>
#include <driverlib/sysctl.h>
#include <driverlib/pin_map.h>

/************************************Includes***************************************/

/*************************************Defines***************************************/
// 16 MHz / 10 = 0.1 s
#define delay_0_1_s     1600000
/*************************************Defines***************************************/
/************************************MAIN*******************************************/

int main(void) {
    // Set system clock speed
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    // Enable relevant port for launchpad switches

    // Configure SW1 input

    // Enable port A

    // Enable UART0 module


    // Configure UART0 pins on port A


    // Set UART clock source

    // Configure UART baud rate


    uint32_t counter = 0;
    while(1) {
        // Print counter value through UART, or display message if button pressed
        if (   ) {
            UARTprintf("Counter value: %d\n", counter);
        } else {
            UARTprintf("Button pressed!\n");
        }

        // Delay by 0.1 ms
        counter++;
        SysCtlDelay(delay_0_1_s);

    }
}
/************************************MAIN*******************************************/
